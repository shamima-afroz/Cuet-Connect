<?php 

$conn= new mysqli('localhost','root','','alumni_db');

?>
