 <!-- Masthead-->


<style>
        .head {
        max-height: 300px !important;
        height: 300px !important;
        background: url(admin/assets/uploads/gallery/7_img.jpeg);
        background-repeat: no-repeat;
        background-size: cover;
       
        
    }
    .heading{

        margin: 150px;
    }


</style>
 <header class="head">
        <div class="row align-items-center justify-content-center text-center">
            <div class="col-lg-3 align-self-end mb-4 heading" >
                    <h4 class="text-white ">About Us</h4>
                   
            </div>
        </div>
</header>

<section class="page-section">
<div class="container text-whiteaz py-4" >
        <p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Fugiat nisi expedita tenetur impedit consequatur! Aliquam numquam ut laboriosam, aut eligendi consectetur quasi? Minus tempora incidunt consectetur doloremque magnam? Delectus non exercitationem cupiditate sint explicabo autem earum labore impedit, eaque modi, animi rerum dignissimos! Doloribus quis expedita earum molestias. Numquam, rem. Quos incidunt optio perspiciatis? Cum, labore est. Aliquam aliquid mollitia quia a rem dolores cumque. Obcaecati ullam iste ut dolor alias. Eos dolorem ea fuga, repudiandae impedit animi rem rerum minima placeat eum vitae debitis architecto amet aliquam aliquid at? Perferendis minima qui eos nulla provident ipsum molestiae optio pariatur?</p>    
    
</div>
</section>